#le simplepage
A simple ZURB's [Foundation](http://foundation.zurb.com/) based page template. 
Simply download and extract the zip file and modify the contents in 
*content* folder and update *js/settings.js* accordingly
