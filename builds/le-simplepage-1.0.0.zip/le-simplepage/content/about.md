# le simplepage
A simple ZURB's [Foundation](foundation.zurb.com) based page template.

Contents for the pages are stored in a separate file in a [Markdown](http://daringfireball.net/projects/markdown/) format. Le simplepage uses [Pagedown](code.google.com/p/pagedown/) to handle markdown to html conversion.


