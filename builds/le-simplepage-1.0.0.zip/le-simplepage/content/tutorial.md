# Tutorial
Simply download the zip files and extract it. Contents are stored in <code>content</code> folder and simply update <code>js/settings.js</code> to point out the links
